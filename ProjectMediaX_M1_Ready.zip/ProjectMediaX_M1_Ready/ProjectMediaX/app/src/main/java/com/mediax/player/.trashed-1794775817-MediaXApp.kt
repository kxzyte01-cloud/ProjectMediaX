package com.mediax.player

import androidx.compose.runtime.Composable
import com.mediax.player.navigation.MediaXNavigation
import com.mediax.player.ui.MainViewModel

@Composable
fun MediaXApp(
    viewModel: MainViewModel,
    onRequestPermissions: () -> Unit,
    onPickMediaFile: (Array<String>) -> Unit
) {
    MediaXNavigation(
        viewModel = viewModel,
        onRequestPermissions = onRequestPermissions,
        onPickMediaFile = onPickMediaFile
    )
}
