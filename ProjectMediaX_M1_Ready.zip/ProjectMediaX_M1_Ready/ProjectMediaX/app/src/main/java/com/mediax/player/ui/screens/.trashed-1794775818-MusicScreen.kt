package com.mediax.player.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AudioFile
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.mediax.player.R
import com.mediax.player.core.model.LocalMediaItem
import com.mediax.player.core.model.TimeFormatters
import com.mediax.player.ui.LibraryUiState

private enum class MusicFilter(val label: String) {
    SONGS("All Songs"),
    FAVORITES("Favorites"),
    ARTISTS("By Artist"),
    ALBUMS("By Album")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MusicScreen(
    libraryState: LibraryUiState,
    favorites: Set<String>,
    onRequestPermissions: () -> Unit,
    onPickAudio: () -> Unit,
    onRefresh: () -> Unit,
    onSearchQueryChange: (String) -> Unit,
    onToggleFavorite: (String) -> Unit,
    onPlayAudio: (LocalMediaItem, List<LocalMediaItem>) -> Unit
) {
    var selectedFilter by rememberSaveable { mutableStateOf(MusicFilter.SONGS) }
    val allAudio = libraryState.allAudio

    val filteredAudio = allAudio.filter { item ->
        val matchesFav = selectedFilter != MusicFilter.FAVORITES || favorites.contains(item.uriString)
        val q = libraryState.searchQuery.trim()
        val matchesSearch = q.isEmpty() ||
            item.title.contains(q, ignoreCase = true) ||
            item.artist.contains(q, ignoreCase = true) ||
            item.album.contains(q, ignoreCase = true)
        matchesFav && matchesSearch
    }.let { list ->
        when (selectedFilter) {
            MusicFilter.ARTISTS -> list.sortedWith(compareBy({ it.artist.lowercase() }, { it.title.lowercase() }))
            MusicFilter.ALBUMS -> list.sortedWith(compareBy({ it.album.lowercase() }, { it.title.lowercase() }))
            else -> list
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.tab_music)) },
                actions = {
                    IconButton(onClick = onRefresh) {
                        Icon(
                            imageVector = Icons.Filled.Refresh,
                            contentDescription = stringResource(R.string.action_refresh)
                        )
                    }
                }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onPickAudio,
                icon = { Icon(Icons.Filled.AudioFile, contentDescription = null) },
                text = { Text(stringResource(R.string.action_open_file)) }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            if (allAudio.isEmpty()) {
                LibraryEmptyState(
                    title = stringResource(R.string.music_empty_title),
                    message = stringResource(R.string.music_empty_message),
                    icon = Icons.Filled.MusicNote,
                    primaryButtonText = stringResource(R.string.action_open_file),
                    onPrimaryClick = onPickAudio,
                    secondaryButtonText = stringResource(R.string.action_scan_library),
                    onSecondaryClick = onRequestPermissions
                )
            } else {
                OutlinedTextField(
                    value = libraryState.searchQuery,
                    onValueChange = onSearchQueryChange,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    placeholder = { Text(stringResource(R.string.search_media_hint)) },
                    leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                    singleLine = true
                )

                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(MusicFilter.entries) { filter ->
                        FilterChip(
                            selected = selectedFilter == filter,
                            onClick = { selectedFilter = filter },
                            label = { Text(filter.label) }
                        )
                    }
                }

                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(filteredAudio, key = { it.uriString }) { track ->
                        val isFav = favorites.contains(track.uriString)
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onPlayAudio(track, filteredAudio) }
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.MusicNote,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = track.title,
                                        style = MaterialTheme.typography.titleMedium,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = "${track.artist} • ${track.album} • ${TimeFormatters.formatDuration(track.durationMs)}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                                IconButton(onClick = { onToggleFavorite(track.uriString) }) {
                                    Icon(
                                        imageVector = if (isFav) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                                        contentDescription = if (isFav) "Remove favorite" else "Add favorite",
                                        tint = if (isFav) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
