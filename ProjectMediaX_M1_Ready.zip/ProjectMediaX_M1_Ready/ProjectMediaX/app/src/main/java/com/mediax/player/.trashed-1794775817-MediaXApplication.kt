package com.mediax.player

import android.app.Application
import android.content.pm.ApplicationInfo
import android.os.StrictMode
import com.mediax.player.core.media.MediaStoreScanner
import com.mediax.player.core.preferences.UserPreferencesRepository
import com.mediax.player.playback.api.PlayerEngine
import com.mediax.player.playback.media3.Media3PlayerEngine

class MediaXApplication : Application() {

    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        val isDebuggable = (applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0
        if (isDebuggable) {
            StrictMode.setThreadPolicy(
                StrictMode.ThreadPolicy.Builder()
                    .detectNetwork()
                    .penaltyLog()
                    .build()
            )
        }
        container = AppContainer(this)
    }
}

class AppContainer(application: Application) {
    val preferencesRepository: UserPreferencesRepository by lazy {
        UserPreferencesRepository(application.applicationContext)
    }

    val mediaStoreScanner: MediaStoreScanner by lazy {
        MediaStoreScanner(application.applicationContext)
    }

    val playerEngine: PlayerEngine by lazy {
        Media3PlayerEngine(
            context = application.applicationContext,
            preferencesRepository = preferencesRepository
        )
    }
}
