package com.mediax.player.core.media

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.provider.OpenableColumns
import com.mediax.player.core.model.LocalMediaItem
import com.mediax.player.core.model.MediaType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

class MediaStoreScanner(private val context: Context) {

    suspend fun scanVideos(): List<LocalMediaItem> = withContext(Dispatchers.IO) {
        val items = mutableListOf<LocalMediaItem>()
        val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        } else {
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        }

        val projection = arrayOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.TITLE,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.BUCKET_DISPLAY_NAME,
            MediaStore.Video.Media.DURATION,
            MediaStore.Video.Media.SIZE,
            MediaStore.Video.Media.DATE_MODIFIED,
            MediaStore.Video.Media.MIME_TYPE
        )

        val sortOrder = "${MediaStore.Video.Media.DATE_MODIFIED} DESC"

        runCatching {
            context.contentResolver.query(
                collection,
                projection,
                null,
                null,
                sortOrder
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.TITLE)
                val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
                val bucketCol = cursor.getColumnIndex(MediaStore.Video.Media.BUCKET_DISPLAY_NAME)
                val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
                val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
                val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_MODIFIED)
                val mimeCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.MIME_TYPE)

                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    val displayName = cursor.getString(nameCol) ?: "Video $id"
                    val title = cursor.getString(titleCol)?.takeIf { it.isNotBlank() }
                        ?: displayName.substringBeforeLast('.')
                    val folder = if (bucketCol >= 0) {
                        cursor.getString(bucketCol)?.takeIf { it.isNotBlank() } ?: "Videos"
                    } else {
                        "Videos"
                    }
                    val durationMs = cursor.getLong(durationCol).coerceAtLeast(0L)
                    val sizeBytes = cursor.getLong(sizeCol).coerceAtLeast(0L)
                    val dateModified = cursor.getLong(dateCol).coerceAtLeast(0L)
                    val mimeType = cursor.getString(mimeCol) ?: "video/*"
                    val contentUri = ContentUris.withAppendedId(collection, id)

                    items.add(
                        LocalMediaItem(
                            id = id,
                            uri = contentUri,
                            title = title,
                            displayName = displayName,
                            folderName = folder,
                            durationMs = durationMs,
                            sizeBytes = sizeBytes,
                            dateModifiedSeconds = dateModified,
                            mimeType = mimeType,
                            mediaType = MediaType.VIDEO
                        )
                    )
                }
            }
        }
        items
    }

    suspend fun scanAudio(): List<LocalMediaItem> = withContext(Dispatchers.IO) {
        val items = mutableListOf<LocalMediaItem>()
        val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        } else {
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        }

        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.DISPLAY_NAME,
            MediaStore.Audio.Media.BUCKET_DISPLAY_NAME,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.SIZE,
            MediaStore.Audio.Media.DATE_MODIFIED,
            MediaStore.Audio.Media.MIME_TYPE
        )

        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0 OR ${MediaStore.Audio.Media.DURATION} >= 5000"
        val sortOrder = "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"

        runCatching {
            context.contentResolver.query(
                collection,
                projection,
                selection,
                null,
                sortOrder
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME)
                val bucketCol = cursor.getColumnIndex(MediaStore.Audio.Media.BUCKET_DISPLAY_NAME)
                val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                val albumCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
                val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)
                val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_MODIFIED)
                val mimeCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.MIME_TYPE)

                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    val displayName = cursor.getString(nameCol) ?: "Track $id"
                    val title = cursor.getString(titleCol)?.takeIf { it.isNotBlank() }
                        ?: displayName.substringBeforeLast('.')
                    val folder = if (bucketCol >= 0) {
                        cursor.getString(bucketCol)?.takeIf { it.isNotBlank() } ?: "Music"
                    } else {
                        "Music"
                    }
                    val artist = cursor.getString(artistCol)
                        ?.takeIf { it.isNotBlank() && it != "<unknown>" } ?: "Unknown Artist"
                    val album = cursor.getString(albumCol)
                        ?.takeIf { it.isNotBlank() && it != "<unknown>" } ?: "Unknown Album"
                    val durationMs = cursor.getLong(durationCol).coerceAtLeast(0L)
                    val sizeBytes = cursor.getLong(sizeCol).coerceAtLeast(0L)
                    val dateModified = cursor.getLong(dateCol).coerceAtLeast(0L)
                    val mimeType = cursor.getString(mimeCol) ?: "audio/*"
                    val contentUri = ContentUris.withAppendedId(collection, id)

                    items.add(
                        LocalMediaItem(
                            id = id,
                            uri = contentUri,
                            title = title,
                            displayName = displayName,
                            folderName = folder,
                            artist = artist,
                            album = album,
                            durationMs = durationMs,
                            sizeBytes = sizeBytes,
                            dateModifiedSeconds = dateModified,
                            mimeType = mimeType,
                            mediaType = MediaType.AUDIO
                        )
                    )
                }
            }
        }
        items
    }

    suspend fun resolvePickedUri(uri: Uri): LocalMediaItem = withContext(Dispatchers.IO) {
        var displayName = uri.lastPathSegment?.substringAfterLast('/') ?: "Picked Media"
        var sizeBytes = 0L

        runCatching {
            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                    if (nameIndex >= 0) {
                        cursor.getString(nameIndex)?.let { displayName = it }
                    }
                    if (sizeIndex >= 0 && !cursor.isNull(sizeIndex)) {
                        sizeBytes = cursor.getLong(sizeIndex)
                    }
                }
            }
        }

        val mimeType = context.contentResolver.getType(uri) ?: ""
        val isAudio = mimeType.startsWith("audio/") ||
            displayName.substringAfterLast('.', "").lowercase() in setOf(
                "mp3", "flac", "wav", "ogg", "opus", "m4a", "aac", "alac", "wma", "ape", "wv"
            )

        val cleanTitle = File(displayName).nameWithoutExtension.ifBlank { displayName }

        LocalMediaItem(
            id = uri.toString().hashCode().toLong(),
            uri = uri,
            title = cleanTitle,
            displayName = displayName,
            folderName = "Picked Files",
            artist = if (isAudio) "Local File" else "",
            album = if (isAudio) "Picked Audio" else "",
            durationMs = 0L,
            sizeBytes = sizeBytes,
            dateModifiedSeconds = System.currentTimeMillis() / 1000L,
            mimeType = mimeType,
            mediaType = if (isAudio) MediaType.AUDIO else MediaType.VIDEO
        )
    }
}
