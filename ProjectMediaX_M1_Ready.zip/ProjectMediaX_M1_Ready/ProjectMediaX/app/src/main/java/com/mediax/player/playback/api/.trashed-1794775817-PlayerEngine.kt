package com.mediax.player.playback.api

import androidx.media3.common.Player
import com.mediax.player.core.model.AspectRatioMode
import com.mediax.player.core.model.LocalMediaItem
import com.mediax.player.core.model.TrackOption
import kotlinx.coroutines.flow.StateFlow

data class PlayerEngineState(
    val currentItem: LocalMediaItem? = null,
    val queue: List<LocalMediaItem> = emptyList(),
    val isPlaying: Boolean = false,
    val isBuffering: Boolean = false,
    val positionMs: Long = 0L,
    val durationMs: Long = 0L,
    val playbackSpeed: Float = 1.0f,
    val aspectRatioMode: AspectRatioMode = AspectRatioMode.FIT,
    val isControlsLocked: Boolean = false,
    val isFullScreenPlayerOpen: Boolean = false,
    val repeatOne: Boolean = false,
    val shuffleEnabled: Boolean = false,
    val audioTracks: List<TrackOption> = emptyList(),
    val subtitleTracks: List<TrackOption> = emptyList(),
    val subtitlesEnabled: Boolean = true,
    val usingSoftwareFallback: Boolean = false,
    val errorMessage: String? = null
)

interface PlayerEngine {
    val state: StateFlow<PlayerEngineState>
    val media3Player: Player

    fun playMedia(item: LocalMediaItem, queue: List<LocalMediaItem> = listOf(item), openFullScreen: Boolean = true)
    fun togglePlayPause()
    fun pause()
    fun seekTo(positionMs: Long)
    fun seekRelative(deltaMs: Long)
    fun setPlaybackSpeed(speed: Float)
    fun cycleAspectRatio()
    fun setControlsLocked(locked: Boolean)
    fun setFullScreenPlayerOpen(open: Boolean)
    fun toggleRepeatOne()
    fun toggleShuffle()
    fun playNext()
    fun playPrevious()
    fun selectAudioTrack(option: TrackOption)
    fun selectSubtitleTrack(option: TrackOption?)
    fun retryWithSoftwareFallback()
    fun dismissError()
    fun stopAndClose()
    fun release()
}
