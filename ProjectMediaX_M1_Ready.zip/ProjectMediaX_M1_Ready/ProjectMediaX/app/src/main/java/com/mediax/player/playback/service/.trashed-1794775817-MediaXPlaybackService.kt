package com.mediax.player.playback.service

import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.mediax.player.MediaXApplication

class MediaXPlaybackService : MediaSessionService() {

    private var mediaSession: MediaSession? = null

    override fun onCreate() {
        super.onCreate()
        val app = application as MediaXApplication
        val player = app.container.playerEngine.media3Player
        mediaSession = MediaSession.Builder(this, player).build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? {
        return mediaSession
    }

    override fun onDestroy() {
        mediaSession?.release()
        mediaSession = null
        super.onDestroy()
    }
}
