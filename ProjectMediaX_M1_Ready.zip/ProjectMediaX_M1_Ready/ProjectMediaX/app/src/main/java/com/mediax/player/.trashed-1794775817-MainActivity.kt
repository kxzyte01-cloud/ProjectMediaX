package com.mediax.player

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.mediax.player.ui.MainViewModel
import com.mediax.player.ui.MediaXTheme

class MainActivity : ComponentActivity() {

    private val mainViewModel: MainViewModel by viewModels {
        val app = application as MediaXApplication
        MainViewModel.factory(app.container)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        handleIncomingIntent(intent)

        setContent {
            val settings by mainViewModel.settingsState.collectAsStateWithLifecycle()

            val permissionLauncher = rememberLauncherForActivityResult(
                contract = ActivityResultContracts.RequestMultiplePermissions()
            ) { result ->
                val granted = result.values.any { it }
                mainViewModel.onPermissionResult(granted)
            }

            val openFileLauncher = rememberLauncherForActivityResult(
                contract = ActivityResultContracts.OpenDocument()
            ) { uri: Uri? ->
                if (uri != null) {
                    runCatching {
                        contentResolver.takePersistableUriPermission(
                            uri,
                            Intent.FLAG_GRANT_READ_URI_PERMISSION
                        )
                    }
                    mainViewModel.openExternalUri(uri)
                }
            }

            LaunchedEffect(Unit) {
                val hasPerm = checkMediaPermissions()
                mainViewModel.onPermissionResult(hasPerm)
            }

            MediaXTheme(
                themeMode = settings.themeMode,
                dynamicColor = settings.dynamicColor
            ) {
                MediaXApp(
                    viewModel = mainViewModel,
                    onRequestPermissions = {
                        permissionLauncher.launch(requiredMediaPermissions())
                    },
                    onPickMediaFile = { mimeTypes ->
                        openFileLauncher.launch(mimeTypes)
                    }
                )
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIncomingIntent(intent)
    }

    override fun onStop() {
        super.onStop()
        val settings = mainViewModel.settingsState.value
        val current = mainViewModel.playerState.value.currentItem
        if (current != null &&
            current.mediaType == com.mediax.player.core.model.MediaType.VIDEO &&
            !settings.backgroundAudioFromVideo &&
            !isInPictureInPictureMode
        ) {
            mainViewModel.playerEngine.pause()
        }
    }

    private fun handleIncomingIntent(intent: Intent?) {
        if (intent?.action == Intent.ACTION_VIEW) {
            intent.data?.let { uri ->
                mainViewModel.openExternalUri(uri)
            }
        }
    }

    private fun requiredMediaPermissions(): Array<String> {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            arrayOf(
                Manifest.permission.READ_MEDIA_VIDEO,
                Manifest.permission.READ_MEDIA_AUDIO
            )
        } else {
            arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
    }

    private fun checkMediaPermissions(): Boolean {
        return requiredMediaPermissions().any { perm ->
            ContextCompat.checkSelfPermission(this, perm) == PackageManager.PERMISSION_GRANTED
        }
    }
}
