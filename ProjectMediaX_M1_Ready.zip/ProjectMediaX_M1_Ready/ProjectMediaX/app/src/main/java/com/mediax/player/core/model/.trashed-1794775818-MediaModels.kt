package com.mediax.player.core.model

import android.net.Uri
import kotlin.math.roundToInt

enum class ThemeMode(val label: String, val description: String) {
    SYSTEM("System Default", "Follow your Android device dark or light setting"),
    LIGHT("Light", "Clean high-contrast daytime appearance"),
    DARK("Dark", "Comfortable dark gray surfaces for low light"),
    AMOLED("AMOLED Pure Black", "True #000000 black background to save battery on OLED screens")
}

enum class AspectRatioMode(val label: String) {
    FIT("Fit"),
    FILL("Stretch"),
    ZOOM("Crop / Zoom"),
    SIXTEEN_NINE("16:9"),
    FOUR_THREE("4:3")
}

enum class MediaType {
    VIDEO,
    AUDIO
}

data class AppSettings(
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val dynamicColor: Boolean = true,
    val advancedMode: Boolean = false,
    val doubleTapSeekSeconds: Int = 10,
    val autoResume: Boolean = true,
    val rememberSpeedPerVideo: Boolean = true,
    val preferHardwareDecoding: Boolean = true,
    val backgroundAudioFromVideo: Boolean = false
)

data class LocalMediaItem(
    val id: Long,
    val uri: Uri,
    val title: String,
    val displayName: String,
    val folderName: String,
    val artist: String = "",
    val album: String = "",
    val durationMs: Long = 0L,
    val sizeBytes: Long = 0L,
    val dateModifiedSeconds: Long = 0L,
    val mimeType: String = "",
    val mediaType: MediaType = MediaType.VIDEO
) {
    val uriString: String get() = uri.toString()
}

data class PlaybackProgress(
    val uriString: String,
    val title: String,
    val positionMs: Long,
    val durationMs: Long,
    val playbackSpeed: Float = 1.0f,
    val lastPlayedEpochMs: Long = 0L
) {
    val progressFraction: Float
        get() = if (durationMs > 0L) {
            (positionMs.toFloat() / durationMs.toFloat()).coerceIn(0f, 1f)
        } else {
            0f
        }

    val isWatched: Boolean
        get() = durationMs > 0L && progressFraction >= 0.90f

    val shouldResume: Boolean
        get() = positionMs >= 3_000L && !isWatched
}

data class TrackOption(
    val groupIndex: Int,
    val trackIndex: Int,
    val label: String,
    val language: String,
    val isSelected: Boolean
)

object TimeFormatters {
    fun formatDuration(durationMs: Long): String {
        if (durationMs <= 0L) return "00:00"
        val totalSeconds = (durationMs / 1000L).coerceAtLeast(0L)
        val hours = totalSeconds / 3600L
        val minutes = (totalSeconds % 3600L) / 60L
        val seconds = totalSeconds % 60L
        return if (hours > 0L) {
            "%d:%02d:%02d".format(hours, minutes, seconds)
        } else {
            "%02d:%02d".format(minutes, seconds)
        }
    }

    fun formatSpeed(speed: Float): String {
        val rounded = (speed * 100).roundToInt() / 100f
        return if (rounded % 1f == 0f) {
            "${rounded.toInt()}x"
        } else {
            "${rounded}x"
        }
    }
}
