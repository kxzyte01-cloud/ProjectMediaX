package com.mediax.player.core.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.mediax.player.core.model.AppSettings
import com.mediax.player.core.model.PlaybackProgress
import com.mediax.player.core.model.ThemeMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "mediax_preferences")

class UserPreferencesRepository(private val context: Context) {

    private object Keys {
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val DYNAMIC_COLOR = booleanPreferencesKey("dynamic_color")
        val ADVANCED_MODE = booleanPreferencesKey("advanced_mode")
        val DOUBLE_TAP_SEEK_SECONDS = intPreferencesKey("double_tap_seek_seconds")
        val AUTO_RESUME = booleanPreferencesKey("auto_resume")
        val REMEMBER_SPEED = booleanPreferencesKey("remember_speed_per_video")
        val PREFER_HW_DECODING = booleanPreferencesKey("prefer_hw_decoding")
        val BG_AUDIO_FROM_VIDEO = booleanPreferencesKey("bg_audio_from_video")
        val FAVORITE_URIS = stringPreferencesKey("favorite_uris_delimited")
        val PROGRESS_RECORDS = stringPreferencesKey("progress_records_v1")
    }

    val settingsFlow: Flow<AppSettings> = context.dataStore.data.map { prefs ->
        val modeName = prefs[Keys.THEME_MODE] ?: ThemeMode.SYSTEM.name
        val themeMode = ThemeMode.entries.firstOrNull { it.name == modeName } ?: ThemeMode.SYSTEM
        AppSettings(
            themeMode = themeMode,
            dynamicColor = prefs[Keys.DYNAMIC_COLOR] ?: true,
            advancedMode = prefs[Keys.ADVANCED_MODE] ?: false,
            doubleTapSeekSeconds = prefs[Keys.DOUBLE_TAP_SEEK_SECONDS] ?: 10,
            autoResume = prefs[Keys.AUTO_RESUME] ?: true,
            rememberSpeedPerVideo = prefs[Keys.REMEMBER_SPEED] ?: true,
            preferHardwareDecoding = prefs[Keys.PREFER_HW_DECODING] ?: true,
            backgroundAudioFromVideo = prefs[Keys.BG_AUDIO_FROM_VIDEO] ?: false
        )
    }

    val favoritesFlow: Flow<Set<String>> = context.dataStore.data.map { prefs ->
        val raw = prefs[Keys.FAVORITE_URIS].orEmpty()
        if (raw.isBlank()) emptySet() else raw.split("\n").filter { it.isNotBlank() }.toSet()
    }

    val progressMapFlow: Flow<Map<String, PlaybackProgress>> = context.dataStore.data.map { prefs ->
        parseProgressMap(prefs[Keys.PROGRESS_RECORDS].orEmpty())
    }

    suspend fun setThemeMode(mode: ThemeMode) {
        context.dataStore.edit { it[Keys.THEME_MODE] = mode.name }
    }

    suspend fun setDynamicColor(enabled: Boolean) {
        context.dataStore.edit { it[Keys.DYNAMIC_COLOR] = enabled }
    }

    suspend fun setAdvancedMode(enabled: Boolean) {
        context.dataStore.edit { it[Keys.ADVANCED_MODE] = enabled }
    }

    suspend fun setDoubleTapSeekSeconds(seconds: Int) {
        context.dataStore.edit { it[Keys.DOUBLE_TAP_SEEK_SECONDS] = seconds.coerceIn(5, 60) }
    }

    suspend fun setAutoResume(enabled: Boolean) {
        context.dataStore.edit { it[Keys.AUTO_RESUME] = enabled }
    }

    suspend fun setRememberSpeedPerVideo(enabled: Boolean) {
        context.dataStore.edit { it[Keys.REMEMBER_SPEED] = enabled }
    }

    suspend fun setPreferHardwareDecoding(enabled: Boolean) {
        context.dataStore.edit { it[Keys.PREFER_HW_DECODING] = enabled }
    }

    suspend fun setBackgroundAudioFromVideo(enabled: Boolean) {
        context.dataStore.edit { it[Keys.BG_AUDIO_FROM_VIDEO] = enabled }
    }

    suspend fun toggleFavorite(uriString: String) {
        context.dataStore.edit { prefs ->
            val current = prefs[Keys.FAVORITE_URIS].orEmpty()
                .split("\n")
                .filter { it.isNotBlank() }
                .toMutableSet()
            if (!current.add(uriString)) {
                current.remove(uriString)
            }
            prefs[Keys.FAVORITE_URIS] = current.joinToString("\n")
        }
    }

    suspend fun savePlaybackProgress(
        uriString: String,
        title: String,
        positionMs: Long,
        durationMs: Long,
        playbackSpeed: Float
    ) {
        if (uriString.isBlank()) return
        context.dataStore.edit { prefs ->
            val current = parseProgressMap(prefs[Keys.PROGRESS_RECORDS].orEmpty()).toMutableMap()
            val safeTitle = title.replace("|", " ").replace("\n", " ").trim()
            current[uriString] = PlaybackProgress(
                uriString = uriString,
                title = safeTitle.ifEmpty { "Media" },
                positionMs = positionMs.coerceAtLeast(0L),
                durationMs = durationMs.coerceAtLeast(0L),
                playbackSpeed = playbackSpeed.coerceIn(0.25f, 4.0f),
                lastPlayedEpochMs = System.currentTimeMillis()
            )
            // Keep most recent 500 items to keep DataStore fast and lightweight
            val trimmed = current.values
                .sortedByDescending { it.lastPlayedEpochMs }
                .take(500)
                .associateBy { it.uriString }
            prefs[Keys.PROGRESS_RECORDS] = serializeProgressMap(trimmed)
        }
    }

    suspend fun getPlaybackProgress(uriString: String): PlaybackProgress? {
        return progressMapFlow.first()[uriString]
    }

    suspend fun clearPlaybackHistory() {
        context.dataStore.edit { prefs ->
            prefs.remove(Keys.PROGRESS_RECORDS)
        }
    }

    companion object {
        internal fun parseProgressMap(raw: String): Map<String, PlaybackProgress> {
            if (raw.isBlank()) return emptyMap()
            val result = mutableMapOf<String, PlaybackProgress>()
            raw.lineSequence().forEach { line ->
                val parts = line.split("|")
                if (parts.size >= 6) {
                    val uri = parts[0]
                    val title = parts[1]
                    val pos = parts[2].toLongOrNull() ?: 0L
                    val dur = parts[3].toLongOrNull() ?: 0L
                    val speed = parts[4].toFloatOrNull() ?: 1.0f
                    val epoch = parts[5].toLongOrNull() ?: 0L
                    if (uri.isNotBlank()) {
                        result[uri] = PlaybackProgress(
                            uriString = uri,
                            title = title,
                            positionMs = pos,
                            durationMs = dur,
                            playbackSpeed = speed,
                            lastPlayedEpochMs = epoch
                        )
                    }
                }
            }
            return result
        }

        internal fun serializeProgressMap(map: Map<String, PlaybackProgress>): String {
            return map.values.joinToString("\n") { item ->
                val cleanUri = item.uriString.replace("|", "%7C").replace("\n", "")
                val cleanTitle = item.title.replace("|", " ").replace("\n", " ")
                "$cleanUri|$cleanTitle|${item.positionMs}|${item.durationMs}|${item.playbackSpeed}|${item.lastPlayedEpochMs}"
            }
        }
    }
}
