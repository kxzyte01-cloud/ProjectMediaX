package com.mediax.player.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.mediax.player.R
import com.mediax.player.core.model.LocalMediaItem
import com.mediax.player.core.model.TimeFormatters
import com.mediax.player.ui.LibraryUiState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BrowseScreen(
    libraryState: LibraryUiState,
    onRequestPermissions: () -> Unit,
    onPickAnyFile: () -> Unit,
    onPlayItem: (LocalMediaItem, List<LocalMediaItem>) -> Unit
) {
    var activeFolder by rememberSaveable { mutableStateOf<String?>(null) }
    val combined = (libraryState.allVideos + libraryState.allAudio).distinctBy { it.uriString }
    val groupedByFolder = combined.groupBy { it.folderName }.toSortedMap()

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(activeFolder ?: stringResource(R.string.tab_browse))
                },
                navigationIcon = {
                    if (activeFolder != null) {
                        IconButton(onClick = { activeFolder = null }) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back to folders")
                        }
                    }
                }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onPickAnyFile,
                icon = { Icon(Icons.Filled.FolderOpen, contentDescription = null) },
                text = { Text(stringResource(R.string.action_open_file)) }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            if (combined.isEmpty()) {
                LibraryEmptyState(
                    title = stringResource(R.string.browse_empty_title),
                    message = stringResource(R.string.browse_empty_message),
                    icon = Icons.Filled.FolderOpen,
                    primaryButtonText = stringResource(R.string.action_open_file),
                    onPrimaryClick = onPickAnyFile,
                    secondaryButtonText = stringResource(R.string.action_scan_library),
                    onSecondaryClick = onRequestPermissions
                )
            } else if (activeFolder == null) {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(groupedByFolder.entries.toList(), key = { it.key }) { (folderName, items) ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { activeFolder = folderName }
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Folder,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary
                                )
                                Spacer(modifier = Modifier.width(14.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = folderName,
                                        style = MaterialTheme.typography.titleMedium
                                    )
                                    Text(
                                        text = "${items.size} media items",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            } else {
                val folderItems = groupedByFolder[activeFolder].orEmpty()
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(folderItems, key = { it.uriString }) { item ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onPlayItem(item, folderItems) }
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.PlayArrow,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = item.title,
                                        style = MaterialTheme.typography.titleMedium,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = "${item.mediaType.name} • ${TimeFormatters.formatDuration(item.durationMs)}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
