package com.mediax.player.ui.screens

import android.os.Build
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.mediax.player.R
import com.mediax.player.core.model.AppSettings
import com.mediax.player.core.model.ThemeMode

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    settings: AppSettings,
    onThemeModeChange: (ThemeMode) -> Unit,
    onDynamicColorChange: (Boolean) -> Unit,
    onAdvancedModeChange: (Boolean) -> Unit,
    onDoubleTapSeekChange: (Int) -> Unit,
    onAutoResumeChange: (Boolean) -> Unit,
    onRememberSpeedChange: (Boolean) -> Unit,
    onPreferHwChange: (Boolean) -> Unit,
    onBgAudioChange: (Boolean) -> Unit,
    onClearHistory: () -> Unit
) {
    var searchQuery by rememberSaveable { mutableStateOf("") }
    var showLicensesDialog by rememberSaveable { mutableStateOf(false) }
    var showClearConfirmDialog by rememberSaveable { mutableStateOf(false) }

    val q = searchQuery.trim().lowercase()
    fun matches(text: String): Boolean = q.isEmpty() || text.lowercase().contains(q)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.tab_settings)) }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text(stringResource(R.string.search_settings_hint)) },
                    leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                    singleLine = true
                )
            }

            item {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = stringResource(R.string.privacy_badge_title),
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = stringResource(R.string.privacy_badge_desc),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                }
            }

            if (matches("Simple Advanced Mode Beginner Power User")) {
                item {
                    SettingSwitchRow(
                        title = "Advanced Mode",
                        description = "Show power-user decoder controls and technical playback options.",
                        checked = settings.advancedMode,
                        onCheckedChange = onAdvancedModeChange
                    )
                }
            }

            if (matches("Theme Appearance Light Dark AMOLED Black Dynamic Color")) {
                item {
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text("Appearance & Theme", style = MaterialTheme.typography.titleMedium)
                            Spacer(modifier = Modifier.height(8.dp))
                            ThemeMode.entries.forEach { mode ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { onThemeModeChange(mode) }
                                        .padding(vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    RadioButton(
                                        selected = settings.themeMode == mode,
                                        onClick = { onThemeModeChange(mode) }
                                    )
                                    Column(modifier = Modifier.padding(start = 8.dp)) {
                                        Text(mode.label, style = MaterialTheme.typography.bodyLarge)
                                        Text(
                                            mode.description,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                                Spacer(modifier = Modifier.height(8.dp))
                                SettingSwitchRow(
                                    title = "Dynamic Wallpaper Colors",
                                    description = "Adapt Material 3 accent colors to your Android 12+ wallpaper.",
                                    checked = settings.dynamicColor,
                                    onCheckedChange = onDynamicColorChange
                                )
                            }
                        }
                    }
                }
            }

            if (matches("Playback Resume Speed Seek Gesture Background Audio")) {
                item {
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Text("Playback & Gestures", style = MaterialTheme.typography.titleMedium)

                            SettingSwitchRow(
                                title = "Resume Where You Left Off",
                                description = "Automatically save and restore playback position for every video.",
                                checked = settings.autoResume,
                                onCheckedChange = onAutoResumeChange
                            )

                            SettingSwitchRow(
                                title = "Remember Speed Per Video",
                                description = "Restore your last chosen playback speed (0.25x to 4x) per file.",
                                checked = settings.rememberSpeedPerVideo,
                                onCheckedChange = onRememberSpeedChange
                            )

                            SettingSwitchRow(
                                title = "Keep Playing Video Audio in Background",
                                description = "Continue playing audio when you switch apps or lock your screen.",
                                checked = settings.backgroundAudioFromVideo,
                                onCheckedChange = onBgAudioChange
                            )

                            Column {
                                Text("Double-Tap Seek Duration", style = MaterialTheme.typography.bodyLarge)
                                Text(
                                    "Seconds skipped when double-tapping the left or right side of the video.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    modifier = Modifier.padding(top = 8.dp)
                                ) {
                                    listOf(5, 10, 15, 30).forEach { sec ->
                                        FilterChip(
                                            selected = settings.doubleTapSeekSeconds == sec,
                                            onClick = { onDoubleTapSeekChange(sec) },
                                            label = { Text("${sec}s") }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            if (settings.advancedMode && matches("Hardware Software Decoder Engine Advanced")) {
                item {
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Text("Advanced Decoder Settings", style = MaterialTheme.typography.titleMedium)
                            SettingSwitchRow(
                                title = "Prefer Hardware Decoding (MediaCodec)",
                                description = "Use hardware acceleration first for best battery life, with automatic software fallback.",
                                checked = settings.preferHardwareDecoding,
                                onCheckedChange = onPreferHwChange
                            )
                        }
                    }
                }
            }

            if (matches("History Privacy Licenses Open Source Clear")) {
                item {
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text("Data & Open Source Licenses", style = MaterialTheme.typography.titleMedium)
                            OutlinedButton(
                                onClick = { showClearConfirmDialog = true },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("Clear Playback History & Resume Positions")
                            }
                            OutlinedButton(
                                onClick = { showLicensesDialog = true },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("View Open Source Licenses")
                            }
                        }
                    }
                }
            }
        }
    }

    if (showClearConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showClearConfirmDialog = false },
            title = { Text("Clear Playback History?") },
            text = { Text("This removes all saved resume positions and watched markers. Your media files on disk will not be touched.") },
            confirmButton = {
                TextButton(
                    onClick = {
                        onClearHistory()
                        showClearConfirmDialog = false
                    }
                ) {
                    Text("Clear History")
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearConfirmDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    if (showLicensesDialog) {
        AlertDialog(
            onDismissRequest = { showLicensesDialog = false },
            title = { Text("Open Source Licenses") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("• AndroidX Jetpack, Compose, DataStore & Media3/ExoPlayer — Apache License 2.0")
                    Text("• Kotlin Standard Library & Coroutines — Apache License 2.0")
                    Text("• Planned M3 Secondary Engine (libVLC / FFmpeg audio extension) — LGPLv2.1+ dynamically linked")
                }
            },
            confirmButton = {
                TextButton(onClick = { showLicensesDialog = false }) {
                    Text("Close")
                }
            }
        )
    }
}

@Composable
private fun SettingSwitchRow(
    title: String,
    description: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onCheckedChange(!checked) }
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(
            modifier = Modifier
                .weight(1f)
                .padding(end = 12.dp)
        ) {
            Text(text = title, style = MaterialTheme.typography.bodyLarge)
            Text(
                text = description,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}
