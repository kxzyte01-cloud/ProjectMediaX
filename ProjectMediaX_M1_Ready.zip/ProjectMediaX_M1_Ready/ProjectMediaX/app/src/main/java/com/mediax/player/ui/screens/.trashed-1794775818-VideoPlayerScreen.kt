package com.mediax.player.ui.screens

import android.app.Activity
import android.content.Context
import android.media.AudioManager
import androidx.activity.compose.BackHandler
import androidx.annotation.OptIn
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AspectRatio
import androidx.compose.material.icons.filled.Forward10
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Replay10
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Subtitles
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.util.UnstableApi
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.mediax.player.core.model.AppSettings
import com.mediax.player.core.model.AspectRatioMode
import com.mediax.player.core.model.TimeFormatters
import com.mediax.player.playback.api.PlayerEngine
import com.mediax.player.playback.api.PlayerEngineState
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

@OptIn(UnstableApi::class)
@Composable
fun VideoPlayerScreen(
    playerEngine: PlayerEngine,
    playerState: PlayerEngineState,
    settings: AppSettings,
    onCloseFullScreen: () -> Unit
) {
    BackHandler(onBack = onCloseFullScreen)

    val context = LocalContext.current
    val activity = context as? Activity
    val audioManager = remember(context) {
        context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    }

    var controlsVisible by remember { mutableStateOf(true) }
    var gestureBanner by remember { mutableStateOf<String?>(null) }
    var showSpeedDialog by remember { mutableStateOf(false) }
    var showTracksDialog by remember { mutableStateOf(false) }
    var speedBeforeLongPress by remember { mutableFloatStateOf(playerState.playbackSpeed) }

    LaunchedEffect(controlsVisible, playerState.isPlaying, playerState.isControlsLocked) {
        if (controlsVisible && playerState.isPlaying && !playerState.isControlsLocked) {
            delay(4_000L)
            controlsVisible = false
        }
    }

    LaunchedEffect(gestureBanner) {
        if (gestureBanner != null) {
            delay(1_200L)
            gestureBanner = null
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .pointerInput(playerState.isControlsLocked, settings.doubleTapSeekSeconds) {
                detectTapGestures(
                    onTap = {
                        controlsVisible = !controlsVisible
                    },
                    onDoubleTap = { offset ->
                        if (playerState.isControlsLocked) return@detectTapGestures
                        val deltaSec = settings.doubleTapSeekSeconds
                        if (offset.x < size.width / 2f) {
                            playerEngine.seekRelative(-deltaSec * 1_000L)
                            gestureBanner = "⏪ -${deltaSec}s"
                        } else {
                            playerEngine.seekRelative(deltaSec * 1_000L)
                            gestureBanner = "⏩ +${deltaSec}s"
                        }
                    },
                    onLongPress = {
                        if (playerState.isControlsLocked) return@detectTapGestures
                        speedBeforeLongPress = playerState.playbackSpeed
                        playerEngine.setPlaybackSpeed(2.0f)
                        gestureBanner = "⚡ 2.0x Speed"
                    },
                    onPress = {
                        tryAwaitRelease()
                        if (!playerState.isControlsLocked && gestureBanner == "⚡ 2.0x Speed") {
                            playerEngine.setPlaybackSpeed(speedBeforeLongPress)
                            gestureBanner = "Speed ${TimeFormatters.formatSpeed(speedBeforeLongPress)}"
                        }
                    }
                )
            }
            .pointerInput(playerState.isControlsLocked) {
                var dragMode = 0 // 1 = seek, 2 = brightness (left), 3 = volume (right)
                var startX = 0f
                detectDragGestures(
                    onDragStart = { offset ->
                        startX = offset.x
                        dragMode = 0
                    },
                    onDrag = { change, dragAmount ->
                        if (playerState.isControlsLocked) return@detectDragGestures
                        change.consume()
                        if (dragMode == 0) {
                            dragMode = if (kotlin.math.abs(dragAmount.x) > kotlin.math.abs(dragAmount.y)) {
                                1
                            } else if (startX < size.width / 2f) {
                                2
                            } else {
                                3
                            }
                        }
                        when (dragMode) {
                            1 -> {
                                val deltaMs = (dragAmount.x / size.width.coerceAtLeast(1)) * 90_000f
                                playerEngine.seekRelative(deltaMs.toLong())
                                gestureBanner = "Seek: ${TimeFormatters.formatDuration(playerState.positionMs)}"
                            }
                            2 -> {
                                val window = activity?.window
                                if (window != null) {
                                    val lp = window.attributes
                                    val current = if (lp.screenBrightness < 0f) 0.5f else lp.screenBrightness
                                    val next = (current - dragAmount.y / size.height.coerceAtLeast(1)).coerceIn(0.05f, 1.0f)
                                    lp.screenBrightness = next
                                    window.attributes = lp
                                    gestureBanner = "☀ Brightness: ${(next * 100).roundToInt()}%"
                                }
                            }
                            3 -> {
                                val maxVol = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
                                val curVol = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
                                val step = if (dragAmount.y < -12f) 1 else if (dragAmount.y > 12f) -1 else 0
                                if (step != 0) {
                                    val nextVol = (curVol + step).coerceIn(0, maxVol)
                                    audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, nextVol, 0)
                                    val pct = ((nextVol.toFloat() / maxVol.toFloat()) * 100).roundToInt()
                                    gestureBanner = "🔊 Volume: $pct%"
                                }
                            }
                        }
                    }
                )
            }
    ) {
        AndroidView(
            factory = { ctx ->
                PlayerView(ctx).apply {
                    useController = false
                    player = playerEngine.media3Player
                    keepScreenOn = true
                }
            },
            update = { view ->
                view.player = playerEngine.media3Player
                view.resizeMode = when (playerState.aspectRatioMode) {
                    AspectRatioMode.FIT -> AspectRatioFrameLayout.RESIZE_MODE_FIT
                    AspectRatioMode.FILL -> AspectRatioFrameLayout.RESIZE_MODE_FILL
                    AspectRatioMode.ZOOM -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                    AspectRatioMode.SIXTEEN_NINE -> AspectRatioFrameLayout.RESIZE_MODE_FIXED_WIDTH
                    AspectRatioMode.FOUR_THREE -> AspectRatioFrameLayout.RESIZE_MODE_FIXED_HEIGHT
                }
            },
            modifier = Modifier.fillMaxSize()
        )

        if (gestureBanner != null) {
            Surface(
                color = Color.Black.copy(alpha = 0.75f),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.align(Alignment.Center)
            ) {
                Text(
                    text = gestureBanner.orEmpty(),
                    color = Color.White,
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp)
                )
            }
        }

        if (controlsVisible) {
            if (playerState.isControlsLocked) {
                IconButton(
                    onClick = { playerEngine.setControlsLocked(false) },
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(24.dp)
                        .background(Color.Black.copy(alpha = 0.6f), RoundedCornerShape(50))
                ) {
                    Icon(
                        imageVector = Icons.Filled.Lock,
                        contentDescription = "Unlock controls",
                        tint = Color.White
                    )
                }
            } else {
                // Top Bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.TopCenter)
                        .background(Color.Black.copy(alpha = 0.6f))
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onCloseFullScreen) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back to library",
                            tint = Color.White
                        )
                    }
                    Text(
                        text = playerState.currentItem?.title.orEmpty(),
                        color = Color.White,
                        style = MaterialTheme.typography.titleMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = { showTracksDialog = true }) {
                        Icon(
                            imageVector = Icons.Filled.Subtitles,
                            contentDescription = "Audio and Subtitle Tracks",
                            tint = Color.White
                        )
                    }
                    IconButton(onClick = { showSpeedDialog = true }) {
                        Icon(
                            imageVector = Icons.Filled.Speed,
                            contentDescription = "Playback Speed",
                            tint = Color.White
                        )
                    }
                    IconButton(onClick = {
                        playerEngine.cycleAspectRatio()
                        gestureBanner = "Aspect: ${playerEngine.state.value.aspectRatioMode.label}"
                    }) {
                        Icon(
                            imageVector = Icons.Filled.AspectRatio,
                            contentDescription = "Change Aspect Ratio",
                            tint = Color.White
                        )
                    }
                    IconButton(onClick = { playerEngine.setControlsLocked(true) }) {
                        Icon(
                            imageVector = Icons.Filled.LockOpen,
                            contentDescription = "Lock controls",
                            tint = Color.White
                        )
                    }
                }

                // Center Play/Pause & Seek
                Row(
                    modifier = Modifier.align(Alignment.Center),
                    horizontalArrangement = Arrangement.spacedBy(28.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = { playerEngine.seekRelative(-settings.doubleTapSeekSeconds * 1_000L) },
                        modifier = Modifier.background(Color.Black.copy(alpha = 0.55f), RoundedCornerShape(50))
                    ) {
                        Icon(Icons.Filled.Replay10, contentDescription = "Rewind", tint = Color.White)
                    }
                    IconButton(
                        onClick = { playerEngine.togglePlayPause() },
                        modifier = Modifier.background(Color.Black.copy(alpha = 0.7f), RoundedCornerShape(50))
                    ) {
                        Icon(
                            imageVector = if (playerState.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                            contentDescription = if (playerState.isPlaying) "Pause" else "Play",
                            tint = Color.White
                        )
                    }
                    IconButton(
                        onClick = { playerEngine.seekRelative(settings.doubleTapSeekSeconds * 1_000L) },
                        modifier = Modifier.background(Color.Black.copy(alpha = 0.55f), RoundedCornerShape(50))
                    ) {
                        Icon(Icons.Filled.Forward10, contentDescription = "Fast forward", tint = Color.White)
                    }
                }

                // Bottom Scrubber Bar
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.BottomCenter)
                        .background(Color.Black.copy(alpha = 0.65f))
                        .padding(horizontal = 16.dp, vertical = 10.dp)
                ) {
                    val duration = playerState.durationMs.coerceAtLeast(1L)
                    Slider(
                        value = playerState.positionMs.toFloat().coerceIn(0f, duration.toFloat()),
                        onValueChange = { newPos ->
                            playerEngine.seekTo(newPos.toLong())
                        },
                        valueRange = 0f..duration.toFloat(),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = TimeFormatters.formatDuration(playerState.positionMs),
                            color = Color.White,
                            style = MaterialTheme.typography.bodySmall
                        )
                        Text(
                            text = "${TimeFormatters.formatSpeed(playerState.playbackSpeed)} • ${playerState.aspectRatioMode.label}",
                            color = Color.White.copy(alpha = 0.85f),
                            style = MaterialTheme.typography.bodySmall
                        )
                        Text(
                            text = TimeFormatters.formatDuration(playerState.durationMs),
                            color = Color.White,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }
        }
    }

    if (showSpeedDialog) {
        val speeds = listOf(0.25f, 0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 2.0f, 3.0f, 4.0f)
        AlertDialog(
            onDismissRequest = { showSpeedDialog = false },
            title = { Text("Playback Speed") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    speeds.chunked(3).forEach { rowSpeeds ->
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            rowSpeeds.forEach { spd ->
                                FilledTonalButton(
                                    onClick = {
                                        playerEngine.setPlaybackSpeed(spd)
                                        showSpeedDialog = false
                                    }
                                ) {
                                    Text(TimeFormatters.formatSpeed(spd))
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showSpeedDialog = false }) {
                    Text("Close")
                }
            }
        )
    }

    if (showTracksDialog) {
        AlertDialog(
            onDismissRequest = { showTracksDialog = false },
            title = { Text("Audio & Subtitle Tracks") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Audio Tracks", style = MaterialTheme.typography.titleSmall)
                    if (playerState.audioTracks.isEmpty()) {
                        Text("Default audio stream active", style = MaterialTheme.typography.bodySmall)
                    } else {
                        playerState.audioTracks.forEach { track ->
                            TextButton(
                                onClick = {
                                    playerEngine.selectAudioTrack(track)
                                    showTracksDialog = false
                                }
                            ) {
                                Text(if (track.isSelected) "✓ ${track.label}" else track.label)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Subtitles", style = MaterialTheme.typography.titleSmall)
                    TextButton(
                        onClick = {
                            playerEngine.selectSubtitleTrack(null)
                            showTracksDialog = false
                        }
                    ) {
                        Text(if (!playerState.subtitlesEnabled) "✓ Off" else "Turn Off Subtitles")
                    }
                    playerState.subtitleTracks.forEach { sub ->
                        TextButton(
                            onClick = {
                                playerEngine.selectSubtitleTrack(sub)
                                showTracksDialog = false
                            }
                        ) {
                            Text(if (sub.isSelected && playerState.subtitlesEnabled) "✓ ${sub.label}" else sub.label)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showTracksDialog = false }) {
                    Text("Done")
                }
            }
        )
    }

    if (playerState.errorMessage != null) {
        AlertDialog(
            onDismissRequest = { playerEngine.dismissError() },
            title = { Text("Playback Issue") },
            text = { Text(playerState.errorMessage) },
            confirmButton = {
                Button(onClick = { playerEngine.retryWithSoftwareFallback() }) {
                    Text("Try Software Decoder")
                }
            },
            dismissButton = {
                TextButton(onClick = {
                    playerEngine.dismissError()
                    onCloseFullScreen()
                }) {
                    Text("Close")
                }
            }
        )
    }
}
