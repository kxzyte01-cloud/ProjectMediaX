package com.mediax.player.navigation

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.mediax.player.R
import com.mediax.player.core.model.TimeFormatters
import com.mediax.player.playback.api.PlayerEngineState
import com.mediax.player.ui.MainViewModel
import com.mediax.player.ui.screens.BrowseScreen
import com.mediax.player.ui.screens.MusicScreen
import com.mediax.player.ui.screens.SettingsScreen
import com.mediax.player.ui.screens.VideoPlayerScreen
import com.mediax.player.ui.screens.VideosScreen

private data class TabItem(
    val route: String,
    val labelResId: Int,
    val icon: androidx.compose.ui.graphics.vector.ImageVector
)

private val tabs = listOf(
    TabItem("videos", R.string.tab_videos, Icons.Filled.VideoLibrary),
    TabItem("music", R.string.tab_music, Icons.Filled.MusicNote),
    TabItem("browse", R.string.tab_browse, Icons.Filled.FolderOpen),
    TabItem("settings", R.string.tab_settings, Icons.Filled.Settings)
)

@Composable
fun MediaXNavigation(
    viewModel: MainViewModel,
    onRequestPermissions: () -> Unit,
    onPickMediaFile: (Array<String>) -> Unit
) {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route

    val libraryState by viewModel.libraryState.collectAsStateWithLifecycle()
    val settings by viewModel.settingsState.collectAsStateWithLifecycle()
    val favorites by viewModel.favoritesState.collectAsStateWithLifecycle()
    val progressMap by viewModel.progressMapState.collectAsStateWithLifecycle()
    val playerState by viewModel.playerState.collectAsStateWithLifecycle()

    if (playerState.isFullScreenPlayerOpen && playerState.currentItem != null) {
        VideoPlayerScreen(
            playerEngine = viewModel.playerEngine,
            playerState = playerState,
            settings = settings,
            onCloseFullScreen = {
                viewModel.playerEngine.setFullScreenPlayerOpen(false)
            }
        )
        return
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            Column {
                if (playerState.currentItem != null) {
                    MiniPlayerBar(
                        playerState = playerState,
                        onExpand = { viewModel.playerEngine.setFullScreenPlayerOpen(true) },
                        onPlayPause = { viewModel.playerEngine.togglePlayPause() },
                        onNext = { viewModel.playerEngine.playNext() },
                        onClose = { viewModel.playerEngine.stopAndClose() }
                    )
                }
                NavigationBar {
                    tabs.forEach { tab ->
                        val label = stringResource(tab.labelResId)
                        NavigationBarItem(
                            selected = currentRoute == tab.route,
                            onClick = {
                                navController.navigate(tab.route) {
                                    popUpTo(navController.graph.findStartDestination().id) {
                                        saveState = true
                                    }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = { Icon(tab.icon, contentDescription = label) },
                            label = { Text(label) }
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(modifier = Modifier.padding(innerPadding)) {
            NavHost(
                navController = navController,
                startDestination = "videos"
            ) {
                composable("videos") {
                    VideosScreen(
                        libraryState = libraryState,
                        progressMap = progressMap,
                        favorites = favorites,
                        onRequestPermissions = onRequestPermissions,
                        onPickVideo = { onPickMediaFile(arrayOf("video/*", "audio/*")) },
                        onRefresh = { viewModel.refreshLibrary() },
                        onSearchQueryChange = { viewModel.updateSearchQuery(it) },
                        onSelectFolder = { viewModel.selectVideoFolder(it) },
                        onToggleFavorite = { viewModel.toggleFavorite(it) },
                        onPlayVideo = { item, queue ->
                            viewModel.playerEngine.playMedia(item, queue, openFullScreen = true)
                        }
                    )
                }
                composable("music") {
                    MusicScreen(
                        libraryState = libraryState,
                        favorites = favorites,
                        onRequestPermissions = onRequestPermissions,
                        onPickAudio = { onPickMediaFile(arrayOf("audio/*")) },
                        onRefresh = { viewModel.refreshLibrary() },
                        onSearchQueryChange = { viewModel.updateSearchQuery(it) },
                        onToggleFavorite = { viewModel.toggleFavorite(it) },
                        onPlayAudio = { item, queue ->
                            viewModel.playerEngine.playMedia(item, queue, openFullScreen = false)
                        }
                    )
                }
                composable("browse") {
                    BrowseScreen(
                        libraryState = libraryState,
                        onRequestPermissions = onRequestPermissions,
                        onPickAnyFile = { onPickMediaFile(arrayOf("video/*", "audio/*")) },
                        onPlayItem = { item, queue ->
                            viewModel.playerEngine.playMedia(
                                item = item,
                                queue = queue,
                                openFullScreen = item.mediaType == com.mediax.player.core.model.MediaType.VIDEO
                            )
                        }
                    )
                }
                composable("settings") {
                    SettingsScreen(
                        settings = settings,
                        onThemeModeChange = { viewModel.setThemeMode(it) },
                        onDynamicColorChange = { viewModel.setDynamicColor(it) },
                        onAdvancedModeChange = { viewModel.setAdvancedMode(it) },
                        onDoubleTapSeekChange = { viewModel.setDoubleTapSeekSeconds(it) },
                        onAutoResumeChange = { viewModel.setAutoResume(it) },
                        onRememberSpeedChange = { viewModel.setRememberSpeedPerVideo(it) },
                        onPreferHwChange = { viewModel.setPreferHardwareDecoding(it) },
                        onBgAudioChange = { viewModel.setBackgroundAudioFromVideo(it) },
                        onClearHistory = { viewModel.clearHistory() }
                    )
                }
            }
        }
    }
}

@Composable
private fun MiniPlayerBar(
    playerState: PlayerEngineState,
    onExpand: () -> Unit,
    onPlayPause: () -> Unit,
    onNext: () -> Unit,
    onClose: () -> Unit
) {
    val item = playerState.currentItem ?: return
    val progress = if (playerState.durationMs > 0L) {
        (playerState.positionMs.toFloat() / playerState.durationMs.toFloat()).coerceIn(0f, 1f)
    } else {
        0f
    }

    Surface(
        tonalElevation = 6.dp,
        shadowElevation = 4.dp,
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onExpand)
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier.fillMaxWidth()
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .padding(end = 12.dp)
                ) {
                    Text(
                        text = item.title,
                        style = MaterialTheme.typography.titleSmall,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "${TimeFormatters.formatDuration(playerState.positionMs)} / ${TimeFormatters.formatDuration(playerState.durationMs)} • ${TimeFormatters.formatSpeed(playerState.playbackSpeed)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1
                    )
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onPlayPause) {
                        Icon(
                            imageVector = if (playerState.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                            contentDescription = if (playerState.isPlaying) "Pause" else "Play"
                        )
                    }
                    IconButton(onClick = onNext) {
                        Icon(
                            imageVector = Icons.Filled.SkipNext,
                            contentDescription = "Next track"
                        )
                    }
                    IconButton(onClick = onClose) {
                        Icon(
                            imageVector = Icons.Filled.Close,
                            contentDescription = "Stop playback"
                        )
                    }
                }
            }
        }
    }
}
