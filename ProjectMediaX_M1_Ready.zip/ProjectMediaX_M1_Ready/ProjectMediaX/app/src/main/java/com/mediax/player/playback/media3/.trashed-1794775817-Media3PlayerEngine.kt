package com.mediax.player.playback.media3

import android.content.Context
import androidx.annotation.OptIn
import androidx.media3.common.AudioAttributes
import androidx.media3.common.util.UnstableApi
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import com.mediax.player.core.model.AspectRatioMode
import com.mediax.player.core.model.LocalMediaItem
import com.mediax.player.core.model.MediaType
import com.mediax.player.core.model.TrackOption
import com.mediax.player.core.preferences.UserPreferencesRepository
import com.mediax.player.playback.api.PlayerEngine
import com.mediax.player.playback.api.PlayerEngineState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

@OptIn(UnstableApi::class)
class Media3PlayerEngine(
    private val context: Context,
    private val preferencesRepository: UserPreferencesRepository
) : PlayerEngine {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var progressPollingJob: Job? = null
    private var lastSavedEpochMs: Long = 0L

    private val _state = MutableStateFlow(PlayerEngineState())
    override val state: StateFlow<PlayerEngineState> = _state.asStateFlow()

    private var exoPlayer: ExoPlayer = buildExoPlayer(preferSoftware = false)

    override val media3Player: Player
        get() = exoPlayer

    private fun buildExoPlayer(preferSoftware: Boolean): ExoPlayer {
        val renderersFactory = DefaultRenderersFactory(context).apply {
            setEnableDecoderFallback(true)
            setExtensionRendererMode(
                if (preferSoftware) {
                    DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER
                } else {
                    DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON
                }
            )
        }

        val audioAttributes = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
            .build()

        return ExoPlayer.Builder(context, renderersFactory)
            .setAudioAttributes(audioAttributes, true)
            .setHandleAudioBecomingNoisy(true)
            .build()
            .also { player ->
                player.addListener(playerListener)
            }
    }

    private val playerListener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            _state.update {
                it.copy(
                    isPlaying = isPlaying,
                    positionMs = exoPlayer.currentPosition.coerceAtLeast(0L),
                    durationMs = exoPlayer.duration.takeIf { d -> d > 0L } ?: it.durationMs
                )
            }
            if (isPlaying) {
                startProgressLoop()
            } else {
                stopProgressLoop()
                persistCurrentProgressNow()
            }
        }

        override fun onPlaybackStateChanged(playbackState: Int) {
            val duration = exoPlayer.duration.takeIf { it > 0L } ?: _state.value.durationMs
            _state.update {
                it.copy(
                    isBuffering = playbackState == Player.STATE_BUFFERING,
                    durationMs = duration,
                    positionMs = exoPlayer.currentPosition.coerceAtLeast(0L)
                )
            }
            if (playbackState == Player.STATE_ENDED) {
                persistCurrentProgressNow()
            }
        }

        override fun onTracksChanged(tracks: Tracks) {
            val audioOptions = mutableListOf<TrackOption>()
            val subtitleOptions = mutableListOf<TrackOption>()

            tracks.groups.forEachIndexed { groupIdx, group ->
                val trackType = group.type
                for (trackIdx in 0 until group.length) {
                    val format = group.getTrackFormat(trackIdx)
                    val lang = format.language ?: "und"
                    val label = buildString {
                        append(format.label ?: "Track ${trackIdx + 1}")
                        if (!format.language.isNullOrBlank()) {
                            append(" (${format.language})")
                        }
                        if (!format.sampleMimeType.isNullOrBlank()) {
                            append(" • ${format.sampleMimeType?.substringAfter('/')}")
                        }
                    }
                    val isSelected = group.isTrackSelected(trackIdx)
                    val option = TrackOption(
                        groupIndex = groupIdx,
                        trackIndex = trackIdx,
                        label = label,
                        language = lang,
                        isSelected = isSelected
                    )
                    if (trackType == C.TRACK_TYPE_AUDIO) {
                        audioOptions.add(option)
                    } else if (trackType == C.TRACK_TYPE_TEXT) {
                        subtitleOptions.add(option)
                    }
                }
            }

            _state.update {
                it.copy(
                    audioTracks = audioOptions,
                    subtitleTracks = subtitleOptions
                )
            }
        }

        override fun onPlayerError(error: PlaybackException) {
            val readable = buildString {
                append("Could not play this file (${error.errorCodeName}). ")
                append("The container or codec may require software decoding.")
            }
            _state.update {
                it.copy(
                    isPlaying = false,
                    isBuffering = false,
                    errorMessage = readable
                )
            }
        }
    }

    override fun playMedia(
        item: LocalMediaItem,
        queue: List<LocalMediaItem>,
        openFullScreen: Boolean
    ) {
        persistCurrentProgressNow()

        scope.launch {
            val settings = preferencesRepository.settingsFlow.first()
            val savedProgress = preferencesRepository.getPlaybackProgress(item.uriString)
            val resumePosition = if (settings.autoResume && savedProgress != null && savedProgress.shouldResume) {
                savedProgress.positionMs
            } else {
                0L
            }
            val initialSpeed = if (settings.rememberSpeedPerVideo && savedProgress != null) {
                savedProgress.playbackSpeed.coerceIn(0.25f, 4.0f)
            } else {
                1.0f
            }

            val mediaItem = MediaItem.Builder()
                .setMediaId(item.uriString)
                .setUri(item.uri)
                .setMediaMetadata(
                    MediaMetadata.Builder()
                        .setTitle(item.title)
                        .setArtist(item.artist.ifBlank { item.folderName })
                        .setAlbumTitle(item.album)
                        .build()
                )
                .build()

            _state.update {
                it.copy(
                    currentItem = item,
                    queue = queue.ifEmpty { listOf(item) },
                    positionMs = resumePosition,
                    durationMs = item.durationMs,
                    playbackSpeed = initialSpeed,
                    isFullScreenPlayerOpen = openFullScreen && item.mediaType == MediaType.VIDEO,
                    errorMessage = null
                )
            }

            exoPlayer.setMediaItem(mediaItem, resumePosition)
            exoPlayer.playbackParameters = PlaybackParameters(initialSpeed)
            exoPlayer.prepare()
            exoPlayer.playWhenReady = true
        }
    }

    override fun togglePlayPause() {
        if (exoPlayer.isPlaying) {
            exoPlayer.pause()
        } else {
            if (exoPlayer.playbackState == Player.STATE_ENDED) {
                exoPlayer.seekTo(0L)
            }
            exoPlayer.play()
        }
    }

    override fun pause() {
        exoPlayer.pause()
    }

    override fun seekTo(positionMs: Long) {
        val duration = exoPlayer.duration.takeIf { it > 0L } ?: _state.value.durationMs
        val target = if (duration > 0L) positionMs.coerceIn(0L, duration) else positionMs.coerceAtLeast(0L)
        exoPlayer.seekTo(target)
        _state.update { it.copy(positionMs = target) }
        persistCurrentProgressNow()
    }

    override fun seekRelative(deltaMs: Long) {
        seekTo(exoPlayer.currentPosition + deltaMs)
    }

    override fun setPlaybackSpeed(speed: Float) {
        val clamped = speed.coerceIn(0.25f, 4.0f)
        exoPlayer.playbackParameters = PlaybackParameters(clamped)
        _state.update { it.copy(playbackSpeed = clamped) }
        persistCurrentProgressNow()
    }

    override fun cycleAspectRatio() {
        val modes = AspectRatioMode.entries
        val currentIdx = modes.indexOf(_state.value.aspectRatioMode)
        val nextMode = modes[(currentIdx + 1) % modes.size]
        _state.update { it.copy(aspectRatioMode = nextMode) }
    }

    override fun setControlsLocked(locked: Boolean) {
        _state.update { it.copy(isControlsLocked = locked) }
    }

    override fun setFullScreenPlayerOpen(open: Boolean) {
        _state.update { it.copy(isFullScreenPlayerOpen = open) }
    }

    override fun toggleRepeatOne() {
        val nextRepeat = !_state.value.repeatOne
        exoPlayer.repeatMode = if (nextRepeat) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF
        _state.update { it.copy(repeatOne = nextRepeat) }
    }

    override fun toggleShuffle() {
        val nextShuffle = !_state.value.shuffleEnabled
        exoPlayer.shuffleModeEnabled = nextShuffle
        _state.update { it.copy(shuffleEnabled = nextShuffle) }
    }

    override fun playNext() {
        val current = _state.value.currentItem ?: return
        val queue = _state.value.queue
        if (queue.size <= 1) return
        val idx = queue.indexOfFirst { it.uriString == current.uriString }
        val nextIdx = if (idx in 0 until queue.lastIndex) idx + 1 else 0
        playMedia(
            item = queue[nextIdx],
            queue = queue,
            openFullScreen = _state.value.isFullScreenPlayerOpen
        )
    }

    override fun playPrevious() {
        if (exoPlayer.currentPosition > 4_000L) {
            seekTo(0L)
            return
        }
        val current = _state.value.currentItem ?: return
        val queue = _state.value.queue
        if (queue.size <= 1) {
            seekTo(0L)
            return
        }
        val idx = queue.indexOfFirst { it.uriString == current.uriString }
        val prevIdx = if (idx > 0) idx - 1 else queue.lastIndex
        playMedia(
            item = queue[prevIdx],
            queue = queue,
            openFullScreen = _state.value.isFullScreenPlayerOpen
        )
    }

    override fun selectAudioTrack(option: TrackOption) {
        val groups = exoPlayer.currentTracks.groups
        if (option.groupIndex !in groups.indices) return
        val group = groups[option.groupIndex]
        exoPlayer.trackSelectionParameters = exoPlayer.trackSelectionParameters
            .buildUpon()
            .setOverrideForType(TrackSelectionOverride(group.mediaTrackGroup, option.trackIndex))
            .build()
    }

    override fun selectSubtitleTrack(option: TrackOption?) {
        if (option == null) {
            exoPlayer.trackSelectionParameters = exoPlayer.trackSelectionParameters
                .buildUpon()
                .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                .build()
            _state.update { it.copy(subtitlesEnabled = false) }
            return
        }
        val groups = exoPlayer.currentTracks.groups
        if (option.groupIndex !in groups.indices) return
        val group = groups[option.groupIndex]
        exoPlayer.trackSelectionParameters = exoPlayer.trackSelectionParameters
            .buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
            .setOverrideForType(TrackSelectionOverride(group.mediaTrackGroup, option.trackIndex))
            .build()
        _state.update { it.copy(subtitlesEnabled = true) }
    }

    override fun retryWithSoftwareFallback() {
        val snapshot = _state.value
        val item = snapshot.currentItem ?: return
        val resumePos = snapshot.positionMs
        val speed = snapshot.playbackSpeed

        exoPlayer.removeListener(playerListener)
        exoPlayer.release()
        exoPlayer = buildExoPlayer(preferSoftware = true)

        _state.update {
            it.copy(
                usingSoftwareFallback = true,
                errorMessage = null
            )
        }

        val mediaItem = MediaItem.Builder()
            .setMediaId(item.uriString)
            .setUri(item.uri)
            .build()
        exoPlayer.setMediaItem(mediaItem, resumePos)
        exoPlayer.playbackParameters = PlaybackParameters(speed)
        exoPlayer.prepare()
        exoPlayer.playWhenReady = true
    }

    override fun dismissError() {
        _state.update { it.copy(errorMessage = null) }
    }

    override fun stopAndClose() {
        persistCurrentProgressNow()
        stopProgressLoop()
        exoPlayer.stop()
        exoPlayer.clearMediaItems()
        _state.update {
            PlayerEngineState()
        }
    }

    override fun release() {
        persistCurrentProgressNow()
        stopProgressLoop()
        exoPlayer.removeListener(playerListener)
        exoPlayer.release()
    }

    private fun startProgressLoop() {
        progressPollingJob?.cancel()
        progressPollingJob = scope.launch {
            while (isActive) {
                val pos = exoPlayer.currentPosition.coerceAtLeast(0L)
                val dur = exoPlayer.duration.takeIf { it > 0L } ?: _state.value.durationMs
                _state.update {
                    it.copy(
                        positionMs = pos,
                        durationMs = dur
                    )
                }
                val now = System.currentTimeMillis()
                if (now - lastSavedEpochMs >= 2_000L) {
                    lastSavedEpochMs = now
                    persistProgress(pos, dur)
                }
                delay(500L)
            }
        }
    }

    private fun stopProgressLoop() {
        progressPollingJob?.cancel()
        progressPollingJob = null
    }

    private fun persistCurrentProgressNow() {
        val current = _state.value.currentItem ?: return
        val pos = exoPlayer.currentPosition.coerceAtLeast(_state.value.positionMs)
        val dur = exoPlayer.duration.takeIf { it > 0L } ?: _state.value.durationMs
        scope.launch {
            preferencesRepository.savePlaybackProgress(
                uriString = current.uriString,
                title = current.title,
                positionMs = pos,
                durationMs = dur,
                playbackSpeed = _state.value.playbackSpeed
            )
        }
    }

    private suspend fun persistProgress(positionMs: Long, durationMs: Long) {
        val current = _state.value.currentItem ?: return
        preferencesRepository.savePlaybackProgress(
            uriString = current.uriString,
            title = current.title,
            positionMs = positionMs,
            durationMs = durationMs,
            playbackSpeed = _state.value.playbackSpeed
        )
    }
}
