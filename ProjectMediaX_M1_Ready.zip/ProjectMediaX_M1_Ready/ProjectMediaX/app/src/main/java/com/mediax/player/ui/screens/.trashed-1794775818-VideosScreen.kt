package com.mediax.player.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.mediax.player.R
import com.mediax.player.core.model.LocalMediaItem
import com.mediax.player.core.model.PlaybackProgress
import com.mediax.player.core.model.TimeFormatters
import com.mediax.player.ui.LibraryUiState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VideosScreen(
    libraryState: LibraryUiState,
    progressMap: Map<String, PlaybackProgress>,
    favorites: Set<String>,
    onRequestPermissions: () -> Unit,
    onPickVideo: () -> Unit,
    onRefresh: () -> Unit,
    onSearchQueryChange: (String) -> Unit,
    onSelectFolder: (String?) -> Unit,
    onToggleFavorite: (String) -> Unit,
    onPlayVideo: (LocalMediaItem, List<LocalMediaItem>) -> Unit
) {
    val allVideos = libraryState.allVideos
    val folders = allVideos.map { it.folderName }.distinct().sorted()

    val filteredVideos = allVideos.filter { item ->
        val matchesFolder = libraryState.selectedVideoFolder == null || item.folderName == libraryState.selectedVideoFolder
        val q = libraryState.searchQuery.trim()
        val matchesSearch = q.isEmpty() ||
            item.title.contains(q, ignoreCase = true) ||
            item.folderName.contains(q, ignoreCase = true)
        matchesFolder && matchesSearch
    }

    val continueWatchingItems = allVideos.mapNotNull { video ->
        val prog = progressMap[video.uriString]
        if (prog != null && prog.shouldResume) Pair(video, prog) else null
    }.sortedByDescending { it.second.lastPlayedEpochMs }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.tab_videos)) },
                actions = {
                    IconButton(onClick = onRefresh) {
                        Icon(
                            imageVector = Icons.Filled.Refresh,
                            contentDescription = stringResource(R.string.action_refresh)
                        )
                    }
                }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onPickVideo,
                icon = { Icon(Icons.Filled.FolderOpen, contentDescription = null) },
                text = { Text(stringResource(R.string.action_open_file)) }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            if (libraryState.isScanning) {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            }

            if (allVideos.isEmpty()) {
                LibraryEmptyState(
                    title = stringResource(R.string.videos_empty_title),
                    message = stringResource(R.string.videos_empty_message),
                    icon = Icons.Filled.VideoLibrary,
                    primaryButtonText = stringResource(R.string.action_open_file),
                    onPrimaryClick = onPickVideo,
                    secondaryButtonText = stringResource(R.string.action_scan_library),
                    onSecondaryClick = onRequestPermissions
                )
            } else {
                OutlinedTextField(
                    value = libraryState.searchQuery,
                    onValueChange = onSearchQueryChange,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    placeholder = { Text(stringResource(R.string.search_media_hint)) },
                    leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                    singleLine = true
                )

                if (folders.size > 1) {
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        item {
                            FilterChip(
                                selected = libraryState.selectedVideoFolder == null,
                                onClick = { onSelectFolder(null) },
                                label = { Text("All (${allVideos.size})") }
                            )
                        }
                        items(folders) { folder ->
                            FilterChip(
                                selected = libraryState.selectedVideoFolder == folder,
                                onClick = { onSelectFolder(folder) },
                                label = { Text(folder) }
                            )
                        }
                    }
                }

                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    if (continueWatchingItems.isNotEmpty()) {
                        item {
                            Text(
                                text = stringResource(R.string.continue_watching),
                                style = MaterialTheme.typography.titleMedium,
                                modifier = Modifier.padding(bottom = 8.dp)
                            )
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                items(continueWatchingItems, key = { "cw_${it.first.uriString}" }) { (video, prog) ->
                                    ContinueWatchingCard(
                                        video = video,
                                        progress = prog,
                                        onClick = { onPlayVideo(video, filteredVideos) }
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                        }
                    }

                    items(filteredVideos, key = { it.uriString }) { video ->
                        val prog = progressMap[video.uriString]
                        val isFav = favorites.contains(video.uriString)
                        VideoListItemCard(
                            video = video,
                            progress = prog,
                            isFavorite = isFav,
                            onFavoriteToggle = { onToggleFavorite(video.uriString) },
                            onClick = { onPlayVideo(video, filteredVideos) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ContinueWatchingCard(
    video: LocalMediaItem,
    progress: PlaybackProgress,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .width(220.dp)
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.secondaryContainer
        )
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(
                text = video.title,
                style = MaterialTheme.typography.titleSmall,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "${TimeFormatters.formatDuration(progress.positionMs)} / ${TimeFormatters.formatDuration(progress.durationMs)}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSecondaryContainer
            )
            Spacer(modifier = Modifier.height(8.dp))
            LinearProgressIndicator(
                progress = { progress.progressFraction },
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
private fun VideoListItemCard(
    video: LocalMediaItem,
    progress: PlaybackProgress?,
    isFavorite: Boolean,
    onFavoriteToggle: () -> Unit,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(
                    imageVector = Icons.Filled.PlayArrow,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = video.title,
                        style = MaterialTheme.typography.titleMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "${video.folderName} • ${TimeFormatters.formatDuration(video.durationMs)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                if (progress?.isWatched == true) {
                    Icon(
                        imageVector = Icons.Filled.CheckCircle,
                        contentDescription = "Watched",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(end = 4.dp)
                    )
                }
                IconButton(onClick = onFavoriteToggle) {
                    Icon(
                        imageVector = if (isFavorite) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                        contentDescription = if (isFavorite) "Remove from favorites" else "Add to favorites",
                        tint = if (isFavorite) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            if (progress != null && progress.shouldResume) {
                Spacer(modifier = Modifier.height(8.dp))
                LinearProgressIndicator(
                    progress = { progress.progressFraction },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}
