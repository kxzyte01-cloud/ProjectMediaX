package com.mediax.player.ui

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.mediax.player.AppContainer
import com.mediax.player.core.model.AppSettings
import com.mediax.player.core.model.LocalMediaItem
import com.mediax.player.core.model.MediaType
import com.mediax.player.core.model.PlaybackProgress
import com.mediax.player.core.model.ThemeMode
import com.mediax.player.playback.api.PlayerEngine
import com.mediax.player.playback.api.PlayerEngineState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class LibraryUiState(
    val isScanning: Boolean = false,
    val hasMediaPermission: Boolean = false,
    val videos: List<LocalMediaItem> = emptyList(),
    val audioTracks: List<LocalMediaItem> = emptyList(),
    val pickedItems: List<LocalMediaItem> = emptyList(),
    val searchQuery: String = "",
    val selectedVideoFolder: String? = null
) {
    val allVideos: List<LocalMediaItem>
        get() = (pickedItems.filter { it.mediaType == MediaType.VIDEO } + videos)
            .distinctBy { it.uriString }

    val allAudio: List<LocalMediaItem>
        get() = (pickedItems.filter { it.mediaType == MediaType.AUDIO } + audioTracks)
            .distinctBy { it.uriString }
}

class MainViewModel(
    private val container: AppContainer
) : ViewModel() {

    private val _libraryState = MutableStateFlow(LibraryUiState())
    val libraryState: StateFlow<LibraryUiState> = _libraryState.asStateFlow()

    val settingsState: StateFlow<AppSettings> = container.preferencesRepository.settingsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), AppSettings())

    val favoritesState: StateFlow<Set<String>> = container.preferencesRepository.favoritesFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptySet())

    val progressMapState: StateFlow<Map<String, PlaybackProgress>> = container.preferencesRepository.progressMapFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyMap())

    val playerEngine: PlayerEngine = container.playerEngine
    val playerState: StateFlow<PlayerEngineState> = playerEngine.state

    fun onPermissionResult(granted: Boolean) {
        _libraryState.update { it.copy(hasMediaPermission = granted) }
        if (granted) {
            refreshLibrary()
        }
    }

    fun refreshLibrary() {
        viewModelScope.launch {
            _libraryState.update { it.copy(isScanning = true) }
            val scannedVideos = container.mediaStoreScanner.scanVideos()
            val scannedAudio = container.mediaStoreScanner.scanAudio()
            _libraryState.update {
                it.copy(
                    isScanning = false,
                    videos = scannedVideos,
                    audioTracks = scannedAudio
                )
            }
        }
    }

    fun openExternalUri(uri: Uri) {
        viewModelScope.launch {
            val item = container.mediaStoreScanner.resolvePickedUri(uri)
            _libraryState.update { current ->
                val updatedPicked = listOf(item) + current.pickedItems.filterNot { it.uriString == item.uriString }
                current.copy(pickedItems = updatedPicked)
            }
            playerEngine.playMedia(
                item = item,
                queue = listOf(item),
                openFullScreen = item.mediaType == MediaType.VIDEO
            )
        }
    }

    fun updateSearchQuery(query: String) {
        _libraryState.update { it.copy(searchQuery = query) }
    }

    fun selectVideoFolder(folder: String?) {
        _libraryState.update { it.copy(selectedVideoFolder = folder) }
    }

    fun toggleFavorite(uriString: String) {
        viewModelScope.launch {
            container.preferencesRepository.toggleFavorite(uriString)
        }
    }

    fun setThemeMode(mode: ThemeMode) {
        viewModelScope.launch {
            container.preferencesRepository.setThemeMode(mode)
        }
    }

    fun setDynamicColor(enabled: Boolean) {
        viewModelScope.launch {
            container.preferencesRepository.setDynamicColor(enabled)
        }
    }

    fun setAdvancedMode(enabled: Boolean) {
        viewModelScope.launch {
            container.preferencesRepository.setAdvancedMode(enabled)
        }
    }

    fun setDoubleTapSeekSeconds(seconds: Int) {
        viewModelScope.launch {
            container.preferencesRepository.setDoubleTapSeekSeconds(seconds)
        }
    }

    fun setAutoResume(enabled: Boolean) {
        viewModelScope.launch {
            container.preferencesRepository.setAutoResume(enabled)
        }
    }

    fun setRememberSpeedPerVideo(enabled: Boolean) {
        viewModelScope.launch {
            container.preferencesRepository.setRememberSpeedPerVideo(enabled)
        }
    }

    fun setPreferHardwareDecoding(enabled: Boolean) {
        viewModelScope.launch {
            container.preferencesRepository.setPreferHardwareDecoding(enabled)
        }
    }

    fun setBackgroundAudioFromVideo(enabled: Boolean) {
        viewModelScope.launch {
            container.preferencesRepository.setBackgroundAudioFromVideo(enabled)
        }
    }

    fun clearHistory() {
        viewModelScope.launch {
            container.preferencesRepository.clearPlaybackHistory()
        }
    }

    companion object {
        fun factory(container: AppContainer): ViewModelProvider.Factory =
            object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T {
                    return MainViewModel(container) as T
                }
            }
    }
}
