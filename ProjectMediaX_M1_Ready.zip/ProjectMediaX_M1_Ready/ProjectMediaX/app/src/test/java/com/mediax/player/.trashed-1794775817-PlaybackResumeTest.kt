package com.mediax.player

import com.mediax.player.core.model.PlaybackProgress
import com.mediax.player.core.model.TimeFormatters
import com.mediax.player.core.preferences.UserPreferencesRepository
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PlaybackResumeTest {

    @Test
    fun formatDuration_formatsMinutesAndHoursCorrectly() {
        assertEquals("00:00", TimeFormatters.formatDuration(0L))
        assertEquals("01:05", TimeFormatters.formatDuration(65_000L))
        assertEquals("1:01:05", TimeFormatters.formatDuration(3_665_000L))
    }

    @Test
    fun playbackProgress_detectsWatchedAndResumeThresholds() {
        val midProgress = PlaybackProgress(
            uriString = "content://media/external/video/1",
            title = "Sample Video",
            positionMs = 45_000L,
            durationMs = 100_000L
        )
        assertTrue(midProgress.shouldResume)
        assertFalse(midProgress.isWatched)

        val watchedProgress = midProgress.copy(positionMs = 92_000L)
        assertTrue(watchedProgress.isWatched)
        assertFalse(watchedProgress.shouldResume)
    }

    @Test
    fun progressSerialization_roundTripsCleanly() {
        val original = mapOf(
            "content://video/10" to PlaybackProgress(
                uriString = "content://video/10",
                title = "My Movie",
                positionMs = 12_345L,
                durationMs = 60_000L,
                playbackSpeed = 1.5f,
                lastPlayedEpochMs = 1700000000000L
            )
        )
        val raw = UserPreferencesRepository.serializeProgressMap(original)
        val parsed = UserPreferencesRepository.parseProgressMap(raw)
        assertEquals(1, parsed.size)
        val restored = parsed["content://video/10"]!!
        assertEquals("My Movie", restored.title)
        assertEquals(12_345L, restored.positionMs)
        assertEquals(60_000L, restored.durationMs)
        assertEquals(1.5f, restored.playbackSpeed, 0.001f)
    }
}
