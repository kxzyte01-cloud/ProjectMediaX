# Project Media X ProGuard / R8 Rules
-keep class androidx.media3.** { *; }
-dontwarn androidx.media3.**
-keepattributes Signature, InnerClasses, EnclosingMethod
